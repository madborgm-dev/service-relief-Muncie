module.exports = {
  plugins: [
    {
      resolve: `gatsby-theme-service-relief`,
      options: {
        authorName: `some Gatsby folks`,
        authorLink: `https://twitter.com/gatsbyjs`,
      },
    },
  ],
}
